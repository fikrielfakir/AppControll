<?php

return [
    'jwt_secret' => env('JWT_SECRET', 'base64:jtKHZVlWp8fGxE3qRvN2mA7bC1dF5gH6iJ8kL9mN0oP'),
    'fcm_server_key' => env('FCM_SERVER_KEY', 'your_fcm_key_here'),
];
