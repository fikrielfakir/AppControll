<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="bi bi-currency-dollar"></i> AdMob Accounts</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAccountModal">
        <i class="bi bi-plus-circle"></i> Add AdMob Account
    </button>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">AdMob Accounts</h5>
            </div>
            <div class="card-body">
                <table class="table table-hover" id="accountsTable">
                    <thead>
                        <tr>
                            <th>Account Name</th>
                            <th>Publisher ID</th>
                            <th>Status</th>
                            <th>Ad Units</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($account->account_name); ?></strong></td>
                            <td><code><?php echo e($account->publisher_id); ?></code></td>
                            <td>
                                <span class="badge bg-<?php echo e($account->status == 'active' ? 'success' : 'secondary'); ?>">
                                    <?php echo e(ucfirst($account->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($account->ad_units_count ?? 0); ?></td>
                            <td>
                                <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#assignModal<?php echo e($account->id); ?>">
                                    <i class="bi bi-link"></i> Assign
                                </button>
                                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($account->id); ?>">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                                <form method="POST" action="<?php echo e(route('admob.destroy', $account->id)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <div class="modal fade" id="editModal<?php echo e($account->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('admob.update', $account->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit AdMob Account</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Account Name</label>
                                                <input type="text" name="account_name" class="form-control" value="<?php echo e($account->account_name); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Publisher ID</label>
                                                <input type="text" name="publisher_id" class="form-control" value="<?php echo e($account->publisher_id); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Status</label>
                                                <select name="status" class="form-select" required>
                                                    <option value="active" <?php echo e($account->status == 'active' ? 'selected' : ''); ?>>Active</option>
                                                    <option value="inactive" <?php echo e($account->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Update Account</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="assignModal<?php echo e($account->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('admob.assign', [$account->id, ''])); ?>" id="assignForm<?php echo e($account->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Assign to App</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Select App</label>
                                                <select name="app_id" class="form-select" required onchange="document.getElementById('assignForm<?php echo e($account->id); ?>').action = '<?php echo e(route('admob.assign', [$account->id, ''])); ?>' + '/' + this.value">
                                                    <option value="">Choose app...</option>
                                                    <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($app->id); ?>"><?php echo e($app->app_name); ?> (<?php echo e($app->package_name); ?>)</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">AdMob App Account ID</label>
                                                <input type="text" name="account_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx~xxxxxxxxxx">
                                                <small class="text-muted">App-level AdMob ID (with ~)</small>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Banner Ad Unit ID</label>
                                                <input type="text" name="banner_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Interstitial Ad Unit ID</label>
                                                <input type="text" name="interstitial_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Rewarded Ad Unit ID</label>
                                                <input type="text" name="rewarded_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">App Open Ad Unit ID</label>
                                                <input type="text" name="app_open_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Native Ad Unit ID</label>
                                                <input type="text" name="native_id" class="form-control" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Assign Ad Units</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addAccountModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('admob.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add AdMob Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Account Name</label>
                        <input type="text" name="account_name" class="form-control" placeholder="My AdMob Account" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Publisher ID</label>
                        <input type="text" name="publisher_id" class="form-control" placeholder="pub-xxxxxxxxxxxxxxxx" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Create Account</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#accountsTable').DataTable({
        order: [[0, 'asc']]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\appserver\resources\views/admin/admob/index.blade.php ENDPATH**/ ?>