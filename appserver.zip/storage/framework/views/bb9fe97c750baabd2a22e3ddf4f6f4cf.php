<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="bi bi-bell"></i> Push Notifications</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#sendNotificationModal">
        <i class="bi bi-send"></i> Send Notification
    </button>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row mb-3">
    <div class="col-md-12">
        <?php if($firebaseStatus['connected']): ?>
        <div class="alert alert-success">
            <i class="bi bi-check-circle-fill"></i> <strong>Firebase Connected:</strong> <?php echo e($firebaseStatus['message']); ?>

        </div>
        <?php else: ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle-fill"></i> <strong>Firebase Error:</strong> <?php echo e($firebaseStatus['message']); ?>

            <br><small class="mt-2 d-block">Please check <code>FIREBASE_CREDENTIALS</code> in your .env file and ensure the service account JSON file exists. See <strong>FIREBASE_SETUP.md</strong> for details.</small>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Notification History</h5>
            </div>
            <div class="card-body">
                <table class="table table-hover" id="notificationsTable">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Message</th>
                            <th>Target App</th>
                            <th>Country</th>
                            <th>Status</th>
                            <th>Sent At</th>
                            <th>Delivered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($notification->title); ?></td>
                            <td><?php echo e(Str::limit($notification->body, 50)); ?></td>
                            <td><?php echo e($notification->app ? $notification->app->app_name : 'All Apps'); ?></td>
                            <td><?php echo e($notification->targeting_rules['countries'][0] ?? 'All'); ?></td>
                            <td>
                                <?php if($notification->status == 'sent'): ?>
                                    <span class="badge bg-success">Sent</span>
                                <?php elseif($notification->status == 'pending'): ?>
                                    <span class="badge bg-warning">Pending</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($notification->status)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($notification->sent_at ? $notification->sent_at->format('Y-m-d H:i') : 'Not sent'); ?></td>
                            <td>
                                <?php if($notification->sent_count > 0): ?>
                                    <?php echo e($notification->delivered_count); ?> / <?php echo e($notification->sent_count); ?>

                                    <small class="text-muted">(<?php echo e(round(($notification->delivered_count / $notification->sent_count) * 100)); ?>%)</small>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">No notifications sent yet</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="sendNotificationModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('notifications.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Send Push Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" class="form-control" placeholder="Notification title" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" class="form-control" rows="3" placeholder="Notification message" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Target App</label>
                                <select name="target_app" class="form-select">
                                    <option value="">All Apps</option>
                                    <?php if(isset($apps)): ?>
                                        <?php $__currentLoopData = $apps ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($app->id); ?>"><?php echo e($app->app_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Target Country</label>
                                <input type="text" name="target_country" class="form-control" placeholder="e.g., US, UK, ALL">
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Target Version (Optional)</label>
                        <input type="text" name="target_version" class="form-control" placeholder="e.g., 1.0.0">
                    </div>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> This notification will be sent via Firebase Cloud Messaging (FCM) to all matching devices.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-send"></i> Send Now
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#notificationsTable').DataTable({
        order: [[5, 'desc']]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\appserver\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>